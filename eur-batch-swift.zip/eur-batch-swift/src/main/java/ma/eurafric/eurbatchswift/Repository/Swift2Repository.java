package ma.eurafric.eurbatchswift.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ma.eurafric.eurbatchswift.entities.SwiftReader;

public interface Swift2Repository extends JpaRepository<SwiftReader,Integer> {

}

package ma.eurafric.eurbatchswift.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ma.eurafric.eurbatchswift.entities.TypeChamp;;

public interface TypeChampRepository extends JpaRepository<TypeChamp, Integer> {

}

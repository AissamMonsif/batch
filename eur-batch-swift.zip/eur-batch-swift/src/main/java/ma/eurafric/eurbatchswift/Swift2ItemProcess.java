package ma.eurafric.eurbatchswift;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import ma.eurafric.eurbatchswift.Repository.SwiftRepository;
import ma.eurafric.eurbatchswift.Repository.TypeChampRepository;
import ma.eurafric.eurbatchswift.Repository.TypeSwiftRepository;
import ma.eurafric.eurbatchswift.entities.Swift;
import ma.eurafric.eurbatchswift.entities.SwiftReader;
import ma.eurafric.eurbatchswift.entities.SwiftDetails;
import ma.eurafric.eurbatchswift.entities.TypeChamp;
import ma.eurafric.eurbatchswift.entities.TypeSwift;

public class Swift2ItemProcess implements ItemProcessor<SwiftReader, Swift> {

	String msg = "";
	String sens = "";
	String block4 = "";
	HashMap<String, String> listeFields = new HashMap<String, String>();
	
	@Autowired
	TypeSwiftRepository typeSwiftRepo;

	@Autowired
	SwiftRepository swiftRepository;

	@Autowired
	TypeChampRepository typeChampRepository;

	public Swift process(SwiftReader item) throws Exception {

		Swift swift = new Swift();
		List<SwiftDetails> swiftDetails = new ArrayList<SwiftDetails>();

		if (item.getField2().equals("")) {
			if (item.getField1().startsWith(":")) {
				msg += ";";
			}
			msg += item.getField1();

			return null;

		} else {

			msg += item.getField1();

			if (msg.contains("{2:I")) {

				item.setSens("Entrant");

			} else if (msg.contains("{2:O")) {

				item.setSens("Sortant");

			}
			
			swift.setSens(item.getSens());

			String s = org.apache.commons.lang3.StringUtils.substringBetween(msg, "}{2:", "}{");

			item.setTypeSw("MT" + s.subSequence(1, 4));

			List<TypeSwift> listTypeSwifts = typeSwiftRepo.findAll();

			for (TypeSwift t : listTypeSwifts) {

				if (t.getLibelle().equals(item.getTypeSw()) == true) {

					item.setTypeSw(t.getLibelle());
					swift.setTypeSwift(t);
				}
			}
		

			listeFields = getFields(msg);
			
			for (Entry<String, String> field : listeFields.entrySet()) {

				SwiftDetails detail = new SwiftDetails();

				detail.setTypeChamp(getDetailTypeChamp(field.getKey(), typeChampRepository, swift.getTypeSwift() ));
				detail.setValue(field.getValue());
				detail.setSwift(swift);
				swiftDetails.add(detail);
			}
			swift.setDetails(swiftDetails);

			msg = item.getField2();
			
			return swift;
		}
	}

	public String getBlock4(String message) {
		if (StringUtils.contains(message, "}}{4:;")) {

			return block4 = StringUtils.substringBetween(message, "}}{4:;", "}{5");

		} else if (StringUtils.contains(message, "N}{4:;")) {

			return block4 = StringUtils.substringBetween(message, "N}{4:;", "}{5");
		} else {
			return block4 = "";
		}
	}

	public HashMap<String, String> getFields(String msg) {

		HashMap<String, String> fields = new HashMap<String, String>();

		String block4 = getBlock4(msg);
		String[] str = block4.split(";");

		List<String> al = new ArrayList<String>();
		al = Arrays.asList(str);

		for (String f : al) {

			fields.put(StringUtils.substringBetween(f, ":", ":"), StringUtils.substringAfterLast(f, ":"));

		}
		return fields;

	}

	public TypeChamp getDetailTypeChamp(String key, TypeChampRepository typeChampRepository, TypeSwift typeSwift) {

		List<TypeChamp> champs = typeChampRepository.findAll();

		for (TypeChamp champ : champs) {
			String libelleChamp = champ.getLibelle();
			if (key.equals(libelleChamp)) {
				return champ; 
			}
		}
		return null;



	}
}

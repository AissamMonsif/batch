package ma.eurafric.eurbatchswift.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class SwiftReader {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="field_1")
	private String field1;

	@Column(name="field_2")
	private String field2;

	@Column(name="sens")
	private String sens;

	@Column(name="message")
	private String message;
	
	@Column(name="type_sw")
	private String typeSw;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getField1() {
		return field1;
	}

	public void setField1(String field1) {
		this.field1 = field1;
	}

	public String getField2() {
		return field2;
	}

	public void setField2(String field2) {
		this.field2 = field2;
	}

	public String getSens() {
		return sens;
	}

	public void setSens(String sens) {
		this.sens = sens;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTypeSw() {
		return typeSw;
	}

	public void setTypeSw(String typeSw) {
		this.typeSw = typeSw;
	}

	public SwiftReader() {
		super();
	}
}
